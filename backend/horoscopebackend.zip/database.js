var sqlite3 = require('sqlite3').verbose()

const DBSOURCE = "db.sqlite"

let db = new sqlite3.Database(DBSOURCE, (err) => {
    if (err) {
      // Cannot open database
      console.error(err.message)
      throw err
    }else{
        console.log('Connected to the SQLite database.')
        db.run(`CREATE TABLE ozellikler (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            burc text, 
            aciklama text)`,
        (err) => {
            if (err) {
                // Table already created
                console.log('Database önceden mevcut.')
            }else{
                // Table just created, creating some rows
                var insert = 'INSERT INTO ozellikler (burc, aciklama) VALUES (?,?)'
                db.run(insert, ["oglak","Anlatılan oğlak burcundan çok farklıyım. Siz bilmiyorsunuz."])
                db.run(insert, ["ikizler","Evet ,çok doğru"])
                db.run(insert, ["koc","Neden çok cins bir burcuz?"])
            }
        });  
    }
});

module.exports = db